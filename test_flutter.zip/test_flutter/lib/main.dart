import 'package:flutter/material.dart';
import 'test.dart'; // Importing test.dart

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Main App with Anonymous Widget'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // Navigate to the new page with the AnonymousWidget
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => Scaffold(
                  appBar: AppBar(title: Text('Anonymous Example')),
                  body: Center(child: AnonymousWidget()),
                ),
              ),
            );
          },
          child: Text('Go to Anonymous Page'),
        ),
      ),
    );
  }
}
