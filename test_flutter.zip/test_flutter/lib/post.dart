import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'posts components/add_post_form.dart';

class PostsPage extends StatefulWidget {
  const PostsPage({super.key});

  @override
  State<PostsPage> createState() => _PostsPageState();
}

class _PostsPageState extends State<PostsPage> {
  final PostService postService = PostService();

  final StorageService storageService = StorageService();

  Future<void> _fetchPosts() async {
    setState(() {}); // Trigger a rebuild to reload the posts
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Posts'),
      ),
      floatingActionButton: FloatingActionButton(
        heroTag: 'AddPost',
        child: const Icon(Icons.add),
        onPressed: () {
          // Show the AddPostForm in a bottom sheet
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            builder: (context) {
              return Padding(
                padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom,
                ),
                child: SafeArea(
                  child: AddPostForm(
                    onPostAdded: (title, content, imagePath) async {
                      String? imageUrl;
                      if (imagePath != null) {
                        // Upload image if one is picked
                        imageUrl = await storageService.uploadImage(imagePath);
                      }
                      if (imageUrl != null) {
                        postService.addPost(title, content, imageUrl);
                      } else {
                        postService.addPost(title, content, null);
                      }
                      await _fetchPosts();
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
      body: RefreshIndicator(
        onRefresh: _fetchPosts, // Refresh callback
        child: StreamBuilder<QuerySnapshot>(
          stream: postService.getAllPosts(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            }

            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }

            if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
              return const Center(child: Text('No posts found.'));
            }

            var posts = snapshot.data!.docs;

            return ListView.builder(
              cacheExtent: 9999,
              itemCount: posts.length,
              itemBuilder: (context, index) {
                var post = posts[index].data() as Map<String, dynamic>;
                String postId = posts[index].id;
                String title = post['title'] ?? 'No Title';
                String content = post['content'] ?? 'No Content';
                String? authorId = post['author'] ?? 'Unknown';
                var likes = post['likes'] ?? 0;

                String? imageUrl = post['imageUrl']; // Image URL
                DateTime timestamp =
                    (post['timestamp'] as Timestamp?)?.toDate() ??
                        DateTime.now();

                return GestureDetector(
                  onTap: () {},
                  child: PostItem(
                    postId: postId,
                    postService: postService,
                    title: title,
                    content: content,
                    imageUrl: imageUrl,
                    authorID: authorId,
                    timestamp: timestamp,
                    likes: likes,
                    onDelete: _fetchPosts,
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
