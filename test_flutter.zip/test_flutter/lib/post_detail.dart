import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class PostDetailPage extends StatefulWidget {
  final String postID;
  final String postUserID;

  const PostDetailPage({
    super.key,
    required this.postID,
    required this.postUserID,
  });

  @override
  State<PostDetailPage> createState() => _PostDetailPageState();
}

class _PostDetailPageState extends State<PostDetailPage> {
  late final Future<Post?> _post;
  PostService postService = PostService();
  ChatService chatService = ChatService();
  final TextEditingController _commentController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  late String joinRequestStatus = 'none';
  String? _username;
  String? _profilePictureUrl;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    checkJoinRequestStatus();
    _post = postService.getPost(widget.postID);
    _fetchUserData();
  }

  @override
  void dispose() {
    _commentController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _fetchUserData() async {
    try {
      // Fetch username and profile picture concurrently
      final usernameFuture = postService.getUserName(widget.postUserID);
      final profilePictureFuture =
          profilePictureCache.getProfilePicture(widget.postUserID);

      final results = await Future.wait([usernameFuture, profilePictureFuture]);

      _username = results[0];
      _profilePictureUrl = results[1];
    } catch (e) {
      debugPrint('Error fetching user data: $e');
      _username = 'Unknown User';
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _addComment() async {
    final text = _commentController.text.trim();
    if (text.isNotEmpty) {
      try {
        final newComment = Comment(
          userID: FirebaseAuth.instance.currentUser!.uid,
          text: text,
          timestamp: DateTime.now(),
        );
        await postService.addComment(widget.postID, newComment);
        _commentController.clear();
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error adding comment: $e')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a comment')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: FutureBuilder<Post?>(
          future: _post,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Text('Loading...');
            } else if (snapshot.hasError) {
              return const Text('Error');
            } else if (snapshot.hasData && snapshot.data != null) {
              return Text(snapshot.data!.title);
            } else {
              return const Text('Post Not Found');
            }
          },
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: FutureBuilder<Post?>(
              future: _post,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return const Center(child: Text('Error loading post.'));
                } else if (snapshot.hasData && snapshot.data != null) {
                  final post = snapshot.data!;
                  return SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              CircleAvatar(
                                radius: 24,
                                backgroundImage: _profilePictureUrl != null
                                    ? CachedNetworkImageProvider(
                                        _profilePictureUrl!)
                                    : const AssetImage(
                                            'assets/images/placeholder.png')
                                        as ImageProvider,
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    _isLoading
                                        ? Text(
                                            'Loading...',
                                            style: theme.textTheme.bodyMedium,
                                          )
                                        : Text(
                                            _username ?? 'Unknown User',
                                            style: theme.textTheme.bodyLarge
                                                ?.copyWith(
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                    Text(
                                      DateFormat('MM-dd-yyyy hh:mm a')
                                          .format(post.timestamp),
                                      style:
                                          theme.textTheme.bodySmall?.copyWith(
                                        color: isDark
                                            ? Colors.grey.shade500
                                            : Colors.grey.shade700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Card(
                            elevation: 3,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Column(
                                children: [
                                  if (post.imageUrl != null)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 10),
                                      child: CachedNetworkImage(
                                        imageUrl: post.imageUrl!,
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  Padding(
                                    padding: const EdgeInsets.all(15.0),
                                    child: Text(post.content),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          if (post.content.contains(
                              "Workout Summary")) // Add this condition

                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                if (FirebaseAuth.instance.currentUser!.uid ==
                                    widget.postUserID)
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      ElevatedButton(
                                        onPressed: () =>
                                            _showJoinRequestsDialog("pending"),
                                        child: const Text("See Requests"),
                                      ),
                                      const SizedBox(
                                        width: 8,
                                      ),
                                    ],
                                  )
                                else
                                  ElevatedButton(
                                    onPressed: joinRequestStatus == 'accepted'
                                        ? null // Disable button if accepted
                                        : () => _sendJoinRequest(
                                            joinRequestStatus == 'pending'
                                                ? 'not sent'
                                                : 'pending'),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor:
                                          joinRequestStatus == 'accepted'
                                              ? Colors.grey[100]
                                              : joinRequestStatus == 'pending'
                                                  ? Colors.grey[100]
                                                  : Colors.deepPurple[200],
                                    ),
                                    child: Text(
                                      joinRequestStatus == 'accepted'
                                          ? 'Accepted'
                                          : joinRequestStatus == 'pending'
                                              ? 'Pending'
                                              : 'Join',
                                      style: const TextStyle(
                                          color: Colors.deepPurple),
                                    ),
                                  ),
                              ],
                            ),
                          const SizedBox(height: 10),
                          const Text(
                            'Comments',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const Divider(),
                          StreamBuilder<QuerySnapshot>(
                            stream: postService.getComments(widget.postID),
                            builder: (context, snapshot) {
                              if (snapshot.connectionState ==
                                  ConnectionState.waiting) {
                                return const Center(
                                    child: CircularProgressIndicator());
                              } else if (snapshot.hasError) {
                                return const Center(
                                    child: Text('Error loading comments.'));
                              } else if (snapshot.hasData &&
                                  snapshot.data!.docs.isNotEmpty) {
                                final comments = snapshot.data!.docs.map((doc) {
                                  return Comment.fromJson(
                                      doc.data() as Map<String, dynamic>);
                                }).toList();

                                return ListView.builder(
                                  controller: _scrollController,
                                  shrinkWrap: true,
                                  itemCount: comments.length,
                                  itemBuilder: (context, index) {
                                    final comment = comments[index];
                                    return ListTile(
                                      title: FutureBuilder<String>(
                                          future: postService
                                              .getUserName(comment.userID),
                                          builder: (context, snapshot) {
                                            return Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Text(
                                                    snapshot.data ??
                                                        "Unknown user",
                                                    style: const TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                  Text(
                                                    DateFormat('MMM d, h:mm a')
                                                        .format(
                                                            comment.timestamp),
                                                    style: const TextStyle(
                                                        fontSize: 12,
                                                        color: Colors.grey),
                                                  ),
                                                ]);
                                          }),
                                      subtitle: Card(
                                          child: Padding(
                                        padding: const EdgeInsets.all(15.0),
                                        child: Text(comment.text),
                                      )),
                                    );
                                  },
                                );
                              } else {
                                return const Center(
                                  child: Text(
                                    "No comments yet. Be the first to comment!",
                                    style: TextStyle(color: Colors.grey),
                                  ),
                                );
                              }
                            },
                          ),
                        ],
                      ),
                    ),
                  );
                } else {
                  return const Center(child: Text('Post not found.'));
                }
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      onTapOutside: (event) {
                        FocusManager.instance.primaryFocus?.unfocus();
                      },
                      controller: _commentController,
                      decoration: InputDecoration(
                        hintText: "Add a comment...",
                        filled: true,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send),
                    onPressed: _addComment,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // -------------------------- JOIN REQUESTS ------------------------------------

  Future<void> checkJoinRequestStatus() async {
    // Check if there's an existing join request for this user
    final joinRequest = await FirebaseFirestore.instance
        .collection('posts')
        .doc(widget.postID)
        .collection('join_requests')
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .get();

    setState(() {
      if (joinRequest.exists) {
        joinRequestStatus = joinRequest.data()?['status'] ?? 'none';
      } else {
        joinRequestStatus = 'none';
      }
    });
  }

  void _sendJoinRequest(String status) async {
    // Create or update the join request document
    await FirebaseFirestore.instance
        .collection('posts')
        .doc(widget.postID)
        .collection('join_requests')
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .set({
      'posterID': widget.postUserID,
      'requesterID': FirebaseAuth.instance.currentUser!.uid,
      'status': status,
    });

    setState(() {
      joinRequestStatus = status;
    });
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Join request sent.')),
      );
    }
  }

  void _showJoinRequestsDialog(String status) async {
    // Fetch pending and accepted join requests
    final pendingRequestsSnapshot = await FirebaseFirestore.instance
        .collection('posts')
        .doc(widget.postID)
        .collection('join_requests')
        .where('status', isEqualTo: 'pending')
        .get();

    final acceptedRequestsSnapshot = await FirebaseFirestore.instance
        .collection('posts')
        .doc(widget.postID)
        .collection('join_requests')
        .where('status', isEqualTo: 'accepted')
        .get();

    // Map pending and accepted requests to lists
    List pendingRequests = pendingRequestsSnapshot.docs.map((doc) {
      return {'id': doc.id, ...doc.data()};
    }).toList();

    List acceptedRequests = acceptedRequestsSnapshot.docs.map((doc) {
      return {'id': doc.id, ...doc.data()};
    }).toList();

    // Fetch the post title for chat room creation
    final postSnapshot = await FirebaseFirestore.instance
        .collection('posts')
        .doc(widget.postID)
        .get();
    String postTitle = postSnapshot.data()?['title'] ?? 'No Title';
    String chatRoomName = 'Post Room: $postTitle';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Join Requests'),
          content: SizedBox(
            width: double.maxFinite,
            height: 400, // Adjust the height as needed
            child: DefaultTabController(
              length: 2, // Number of tabs: Pending and Accepted
              child: Column(
                children: [
                  const TabBar(
                    labelColor: Colors.deepPurple,
                    unselectedLabelColor: Colors.grey,
                    indicatorColor: Colors.deepPurple,
                    tabs: [
                      Tab(text: 'Pending'),
                      Tab(text: 'Accepted'),
                    ],
                  ),
                  Expanded(
                    child: TabBarView(
                      children: [
                        _buildRequestList(pendingRequests, 'pending'),
                        Column(
                          children: [
                            if (acceptedRequests.isNotEmpty)
                              ElevatedButton(
                                onPressed: () async {
                                  // Add current user to accepted users
                                  final acceptedUsers = acceptedRequests
                                      .map((req) => req['requesterID'])
                                      .toList();
                                  acceptedUsers.add(
                                      FirebaseAuth.instance.currentUser!.uid);

                                  // Create a chat room
                                  final newRoomId =
                                      await chatService.createChatRoom(
                                    chatRoomName,
                                    acceptedUsers,
                                  );

                                  Navigator.pop(context); // Close the dialog

                                  // Navigate to the chat room
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            ChatPage(roomId: newRoomId)),
                                  );
                                },
                                child: const Text('Create Chat Room'),
                              ),
                            Expanded(
                              child: _buildRequestList(
                                  acceptedRequests, 'accepted'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildRequestList(List requests, String status) {
    if (requests.isEmpty) {
      return Center(
        child: Text(
          status == 'pending' ? 'No pending requests' : 'No accepted requests',
          style: TextStyle(color: Colors.grey[600]),
        ),
      );
    }

    return ListView.builder(
      itemCount: requests.length,
      itemBuilder: (context, index) {
        var request = requests[index];
        var requesterID = request['requesterID'];

        return FutureBuilder<String>(
          future: postService.getUserName(requesterID),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const ListTile(
                title: Text('Loading...'),
                trailing: CircularProgressIndicator(),
              );
            } else if (snapshot.hasError || !snapshot.hasData) {
              return const ListTile(
                title: Text('Error loading user'),
              );
            } else {
              String username = snapshot.data ?? 'Unknown User';

              return ListTile(
                title: Text(username),
                trailing: status == 'pending'
                    ? ElevatedButton(
                        onPressed: () => _acceptJoinRequest(requesterID),
                        child: const Text('Accept'),
                      )
                    : const Icon(Icons.check_circle, color: Colors.green),
              );
            }
          },
        );
      },
    );
  }

  Future<void> _acceptJoinRequest(String requesterID) async {
    // Update the join request status to "accepted" in Firestore
    await FirebaseFirestore.instance
        .collection('posts')
        .doc(widget.postID)
        .collection('join_requests')
        .doc(requesterID)
        .update({'status': 'accepted'});

    // Optionally show a confirmation
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Request from $requesterID accepted.')),
    );

    // Close the dialog
    Navigator.of(context).pop();
    _showJoinRequestsDialog('pending'); // Reopen dialog to refresh the list
  }

  Future<List<String>> fetchAcceptedRequests() async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('posts')
        .doc(widget.postID)
        .collection('join_requests')
        .where('status', isEqualTo: 'accepted')
        .get();

    return querySnapshot.docs
        .map((doc) => doc['requesterID'] as String)
        .toList();
  }
}
