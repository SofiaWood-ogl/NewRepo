import 'package:flutter/material.dart';

class AnonymousWidget extends StatefulWidget {
  @override
  _AnonymousWidgetState createState() => _AnonymousWidgetState();
}

class _AnonymousWidgetState extends State<AnonymousWidget> {
  bool button = false; // Declare button as a state variable

  void anonymous() {
    if (button) {
      print("anonymous");
    } else {
      print("username");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        ElevatedButton(
          child: Text(button ? 'Anonymous' : 'Set as Anonymous'),
          onPressed: () {
            setState(() {
              button = true; // Set button to true when pressed
            });
            anonymous(); // Call anonymous function after updating the state
          },
        ),
        SizedBox(height: 20),
        ElevatedButton(
          child: Text(button ? 'Set as Username' : 'Username'),
          onPressed: () {
            setState(() {
              button = false; // Set button to false when pressed
            });
            anonymous(); // Call anonymous function after updating the state
          },
        ),
      ],
    );
  }
}
